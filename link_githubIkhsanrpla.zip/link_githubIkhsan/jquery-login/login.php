<?php

	$is_ajax = $_REQUEST['is_ajax'];
	if(isset($is_ajax) && $is_ajax)
	{
		$username = $_REQUEST['username'];
		$password = $_REQUEST['password'];
		
		/* 
			:: Catatan
			-----------------------------------------------------------------------------------------
			kamu dapat meletakkan query mysql untuk pengaksesan password dari database disni.
			pada sample ini hanya menggunakan logika sederhana
		*/
		
		if($username == 'ardi' && $password == '12345')
		{
			echo "success";
		}
	}

?>
