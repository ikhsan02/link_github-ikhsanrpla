<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contoh penerapan percabangan if else</title>
</head>
<body>
    <?php
        $nilai_agil = 85;
        if ($nilai_agil>=75 && $nilai_agil<=100) {
            echo"nilai agil bagus tidak di remedial";
        }else {
            echo"nilai agil jelek harus di remedial";
        }
    ?>
</body>
</html>
